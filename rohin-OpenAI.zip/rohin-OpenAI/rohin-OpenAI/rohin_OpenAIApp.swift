//
//  rohin_OpenAIApp.swift
//  rohin-OpenAI
//
//  Created by Rohin Joshi on 4/10/23.
//

import SwiftUI

@main
struct rohin_OpenAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
