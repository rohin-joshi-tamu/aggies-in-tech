//
//  Constants.swift
//  rohin-OpenAI
//
//  Created by Rohin Joshi on 4/10/23.
//

import Foundation

struct K {
    struct apiKey{
        static let rohin_openai_api_key = "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"
    }
}
