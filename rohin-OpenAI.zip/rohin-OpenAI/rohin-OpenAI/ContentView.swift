//
//  ContentView.swift
//  rohin-OpenAI
//
//  Created by Rohin Joshi on 4/10/23.
//

import SwiftUI

struct ContentView: View {
    @State private var tabSelected: Tab = .clipboard
    
    //class initialization
    init() {
        UITabBar.appearance().isHidden = true
    }
    
    var body: some View {
        //changed NavView to hstack
        ZStack {
            VStack {
                TabView(selection: $tabSelected) {
                    ForEach(Tab.allCases, id: \.self) { tab in
                        getView(for: tab)
                            .tag(tab)
                    }
                }
                //swipe between views
                .tabViewStyle(.page)
                
                VStack {
                    //Spacer()
                    CustomTabBar(selectedTab: $tabSelected)
                }//end of VStack
                
            }//end of VStack
            
        }//end of ZStack
    }
    
    private func getView(for tab: Tab) -> some View {
        switch tab {
        case .calendar:
            return AnyView(DALL_E())
        case .clipboard:
            return AnyView(IncompleteSentence())
        case .person:
            return AnyView(SentimentAnalysis())
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
