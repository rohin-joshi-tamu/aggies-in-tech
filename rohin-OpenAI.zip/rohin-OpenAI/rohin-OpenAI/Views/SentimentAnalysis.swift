//
//  SentimentAnalysis.swift
//  rohin-OpenAI
//
//  Created by Rohin Joshi on 4/10/23.
//

import SwiftUI

struct SentimentAnalysis: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SentimentAnalysis_Previews: PreviewProvider {
    static var previews: some View {
        SentimentAnalysis()
    }
}
