//
//  IncompleteSentence.swift
//  rohin-OpenAI
//
//  Created by Rohin Joshi on 4/10/23.
//

import SwiftUI
import OpenAIKit

final class IncompleteSentenceViewModel: ObservableObject {
    private var openai:OpenAI?
    
    func setup() {
        self.openai = OpenAI(Configuration(
            organizationId: "Personal",
            apiKey: K.apiKey.rohin_openai_api_key
        ))
    }

    func completeSentence(prompt: String) async -> String? {
        guard let openai = openai else {
            return nil
        }
        do {
            let completionParameter = CompletionParameters(
                model: "text-davinci-001",
                prompt: [prompt],
                maxTokens: 10,
                temperature: 0.98
            )
            let completionResponse = try await openai.generateCompletion(
                parameters: completionParameter
            )
            let responseText = completionResponse.choices[0].text
            return responseText
        } catch {
            print(String(describing: error))
            return nil
        }
        
    }

}


struct IncompleteSentence: View {
    @ObservedObject var viewModel = IncompleteSentenceViewModel()
    @State var text = ""
    @State var completionResult = ""

    var body: some View {
        VStack {
            TextField("Type incomplete sentence here...", text: $text)
                .padding()
            Button("Complete") {
                if !text.trimmingCharacters(in: .whitespaces).isEmpty {
                    Task {
                        let result = await viewModel.completeSentence(prompt: text)
                        if result == nil {
                            print("failed to complete sentence")
                        }
                        self.completionResult = result ?? ""
                    }
                }
            }
            Spacer()
            Text(completionResult)
                .padding()
        }
        .navigationTitle("OpenAI Sentence Completion")
        .onAppear {
            viewModel.setup()
        }
    }
}

struct IncompleteSentence_Previews: PreviewProvider {
    static var previews: some View {
        IncompleteSentence()
    }
}
