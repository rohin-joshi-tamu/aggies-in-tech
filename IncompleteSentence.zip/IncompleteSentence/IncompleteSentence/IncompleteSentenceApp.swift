//
//  IncompleteSentenceApp.swift
//  IncompleteSentence
//
//  Created by Rohin Joshi on 4/9/23.
//

import SwiftUI

@main
struct IncompleteSentenceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
