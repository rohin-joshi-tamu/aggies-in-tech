//
//  OpenAIApp.swift
//  OpenAI
//
//  Created by Rohin Joshi on 4/9/23.
//

import SwiftUI

@main
struct OpenAIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
